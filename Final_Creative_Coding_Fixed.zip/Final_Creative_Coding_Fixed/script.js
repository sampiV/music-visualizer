let songs = [];            // Array to store loaded songs
let currentSongIndex = 0;  // Currently playing song
let fft;                   // FFT for analysis
let mic;                   // Microphone input for Visualization 6
let micStarted = false;    // Flag to track microphone activation
let currentVisualization = 0; // Active visualization

function preload() {
  // Load MP3 files
  songs.push(loadSound('mp3/song1.mp3'));
  songs.push(loadSound('mp3/song2.mp3'));
  songs.push(loadSound('mp3/song3.mp3'));
  songs.push(loadSound('mp3/song4.mp3'));
  songs.push(loadSound('mp3/song5.mp3'));
}

function setup() {
  createCanvas(800, 600, WEBGL);
  fft = new p5.FFT();

  // Play the first song by default
  songs[currentSongIndex].loop();

  // UI Event Listeners
  document.getElementById('playPause').addEventListener('click', togglePlayPause);
  document.getElementById('shuffle').addEventListener('click', shuffleSong);
  document.getElementById('songSelect').addEventListener('change', selectSong);

  // Initialize visualizations that require setup
  setupEqualizer();
  setUpVis2();
  setUpVis3(); // Call setup for Visualization 3
  setupVis4();
  setupVis5();

  console.log("Setup complete.");
}

function draw() {
  background(0);

  switch (currentVisualization) {
    case 0: vis1(fft); break;
    case 1: vis2(fft); break;
    case 2: vis3(fft); break; // Fixed Visualization 3
    case 3: vis4(fft); break;
    case 4: vis5(fft); break;
    case 5: 
      stopMusicForMic();
      vis6();
      break;
  }
}

function keyPressed() {
  if (key >= '1' && key <= '6') {
    let newVisualization = int(key) - 1;

    // Stop microphone input when switching away from Visualization 6
    if (currentVisualization === 5 && newVisualization !== 5 && micStarted) {
      mic.stop();
      micStarted = false;
      console.log("Microphone input stopped.");
    }

    // Resume music when switching away from Visualization 6
    if (currentVisualization === 5 && newVisualization !== 5) {
      songs[currentSongIndex].play();
      console.log("Music resumed.");
    }

    // Stop music if switching to Visualization 6
    if (newVisualization === 5) {
      stopMusicForMic();
    }

    currentVisualization = newVisualization;
  }
}

// UI Functions
function togglePlayPause() {
  if (songs[currentSongIndex].isPlaying()) {
    songs[currentSongIndex].pause();
  } else {
    songs[currentSongIndex].play();
  }
}

function shuffleSong() {
  songs[currentSongIndex].stop();
  currentSongIndex = floor(random(songs.length));
  songs[currentSongIndex].play();
}

function selectSong(e) {
  let selectedIndex = int(e.target.value);
  if (selectedIndex !== currentSongIndex) {
    songs[currentSongIndex].stop();
    currentSongIndex = selectedIndex;
    songs[currentSongIndex].play();
  }
}

// Stop music and start mic for Visualization 6
function stopMusicForMic() {
  if (!micStarted) {
    if (songs[currentSongIndex].isPlaying()) {
      songs[currentSongIndex].stop();
      console.log("Music stopped for microphone input.");
    }
    mic = new p5.AudioIn();
    mic.start();
    fft.setInput(mic);
    micStarted = true;
    console.log("Microphone input started.");
  }
}

// Visualization Setup
function setupEqualizer() { console.log("Equalizer setup complete."); }
function setUpVis2() { console.log("Visualization 2 setup complete."); }
function setUpVis3() { 
  console.log("Visualization 3 setup complete.");
  particles = []; // Ensure particles are initialized only once
}
function setupVis4() { console.log("Visualization 4 setup complete."); }
function setupVis5() { console.log("Visualization 5 setup complete."); }
