let peakValues = []; // Store peak values for each frequency bar

function setupEqualizer() {
  let numBars = 64; // Number of frequency bands (adjustable)
  for (let i = 0; i < numBars; i++) {
    peakValues.push(0); // Initialize peak values to zero
  }
}

function vis1(fft) {
  background(0); // Black background
  let spectrum = fft.analyze(); // Get the frequency spectrum
  let numBars = peakValues.length;
  let barWidth = width / numBars; // Calculate bar width

  for (let i = 0; i < numBars; i++) {
    let x = i * barWidth - width / 2; // X position of the bar
    let barHeight = map(spectrum[i], 0, 255, 0, height / 1.5); // Map spectrum to bar height

    // Update peak value for the bar
    if (barHeight > peakValues[i]) {
      peakValues[i] = barHeight;
    } else {
      peakValues[i] -= 2; // Gradually lower the peak marker
    }

    // Draw the bar
    noStroke();
    let colorValue = map(i, 0, numBars, 60, 255); // Color gradient
    fill(colorValue, 255, 0); // Yellow-green gradient
    rect(x, height / 2 - barHeight, barWidth - 2, barHeight);

    // Draw the peak marker
    fill(255, 0, 0); // Red color for peak marker
    rect(x, height / 2 - peakValues[i] - 5, barWidth - 2, 5); // Small rectangle as peak marker
  }
}
