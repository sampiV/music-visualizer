let video; // Webcam capture
let videoScale = 8; // Grid resolution (smaller = fewer circles, larger size)
let cols, rows; // Columns and rows based on video size
let particles = []; // Array to store particles

function setupVis5() {
  console.log("Webcam Visualization 5 initialized");

  // Set up the canvas
  createCanvas(windowWidth, windowHeight);

  // Properly scale the video feed
  video = createCapture(VIDEO);
  video.size(floor(width / videoScale), floor(height / videoScale));
  video.hide();

  // Calculate columns and rows based on video dimensions
  cols = video.width;
  rows = video.height;
}

function vis5(fft) {
  background(0, 50); // Semi-transparent background for trails
  translate(-width / 2, -height / 2);
  video.loadPixels();
  let spectrum = fft.analyze();
  let bass = fft.getEnergy("bass");

  // Calculate offsets to center the visualization
  let offsetX = (width - cols * videoScale) / 2; // Horizontal offset
  let offsetY = (height - rows * videoScale) / 2; // Vertical offset

  // Loop through the webcam grid to draw ellipses and particles
  for (let y = 0; y < rows; y = y + 3) {
    for (let x = 0; x < cols; x = x + 3) {
      let index = (x + y * cols) * 4; // Index for video pixels
      let r = video.pixels[index];
      let g = video.pixels[index + 1];
      let b = video.pixels[index + 2];
      let brightness = (r + g + b) / 3; // Average brightness

      // Draw grid-based ellipses
      let size = map(brightness, 0, 255, 2, videoScale * 1.5) * (bass / 128);
      fill(r, g, b, 200);
      noStroke();
      ellipse(x * videoScale + offsetX, y * videoScale + offsetY, size, size);

      // Add particles from bright pixels
      if (brightness > 150 && random() < 0.05) {
        particles.push({
          x: x * videoScale + offsetX,
          y: y * videoScale + offsetY,
          vx: random(-1, 1),
          vy: random(-1, 1),
          lifespan: 255,
          color: color(r, g, b),
        });
      }
    }
  }

  // Update and draw particles
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    fill(p.color, p.lifespan);
    noStroke();
    ellipse(p.x, p.y, 5, 5);

    // Update particle position and lifespan
    p.x += p.vx;
    p.y += p.vy;
    p.lifespan -= 4;

    // Remove dead particles
    if (p.lifespan <= 0) {
      particles.splice(i, 1);
    }
  }
}

// Responsive resizing for canvas and video
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  video.size(floor(width / videoScale), floor(height / videoScale));
  cols = video.width;
  rows = video.height;
}
