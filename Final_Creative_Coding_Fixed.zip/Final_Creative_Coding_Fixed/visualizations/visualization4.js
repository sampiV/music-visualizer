function vis4(fft) {
    let spectrum = fft.analyze();
    background(0, 10); // Slightly transparent for a trail effect
    noFill();
    strokeWeight(2);
  
    let maxRadius = width / 3;
  
    for (let i = 0; i < spectrum.length; i += 10) {
      let angle = map(i, 0, spectrum.length, 0, TWO_PI);
      let radius = map(spectrum[i], 0, 255, 50, maxRadius);
  
      stroke(255, 100, i % 255); // Gradient colors
      push();
      rotate(frameCount * 0.01);
      arc(0, 0, radius, radius, angle, angle + QUARTER_PI);
      pop();
    }
  }
  