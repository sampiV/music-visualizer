function vis2(fft) {
    let waveform = fft.waveform(); // Get the waveform
    noFill();
    stroke(255, 0, 255); // Purple waveform
    strokeWeight(2);
  
    beginShape();
    for (let i = 0; i < waveform.length; i++) {
      let x = map(i, 0, waveform.length, -width / 2, width / 2);
      let y = map(waveform[i], -1, 1, -height / 2, height / 2);
      vertex(x, y);
    }
    endShape();
  }
  