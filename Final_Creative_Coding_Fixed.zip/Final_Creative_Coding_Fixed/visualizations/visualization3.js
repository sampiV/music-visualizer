let angleOffset = 0;

function setUpVis3() {
  console.log("Rotating 3D Grid initialized");
}

function vis3(fft) {
  background(20);
  rotateX(angleOffset);
  rotateY(angleOffset);

  let spectrum = fft.analyze();
  let gridSize = 10; // Grid resolution
  let maxHeight = 300;

  for (let x = -200; x <= 200; x += gridSize) {
    for (let z = -200; z <= 200; z += gridSize) {
      let index = (x + 200 + (z + 200) * 40) % spectrum.length;
      let height = map(spectrum[index], 0, 255, 0, maxHeight);

      push();
      translate(x, -height / 2, z);
      fill(lerpColor(color("#6BA292"), color("#D32F2F"), height / maxHeight));
      box(gridSize, height, gridSize);
      pop();
    }
  }

  angleOffset += 0.01; // Rotate gradually
}
