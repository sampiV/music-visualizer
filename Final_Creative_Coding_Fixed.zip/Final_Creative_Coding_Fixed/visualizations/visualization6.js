function vis6() {
    background(0, 50); // Add slight transparency for a smooth trail effect
  
    let spectrum = fft.analyze(); // Get the frequency spectrum
    let numBars = 64; // Number of bars
    let barWidth = width / numBars;
  
    noStroke();
  
    for (let i = 0; i < numBars; i++) {
      let x = i * barWidth - width / 2; // Center the spectrum
      let barHeight = map(spectrum[i], 0, 255, 0, height / 1.5); // Map spectrum to bar height
  
      // Dynamic colors based on spectrum energy and index
      let r = map(spectrum[i], 0, 255, 100, 255); // Red based on spectrum amplitude
      let g = map(i, 0, numBars, 50, 200); // Green gradient
      let b = map(barHeight, 0, height / 1.5, 200, 255); // Blue based on height
  
      fill(r, g, b, 200); // Add some transparency for better blending
      rect(x, height / 2 - barHeight, barWidth - 2, barHeight); // Draw the bars
    }
  
    // Add an optional glowing effect
    drawGlowingEffect();
  }
  
  function drawGlowingEffect() {
    noFill();
    stroke(0, 150, 255, 80); // Light blue glow
    strokeWeight(2);
  
    let glowRadius = map(fft.getEnergy("bass"), 0, 255, 100, 300); // Glow responds to bass energy
    ellipse(0, 0, glowRadius, glowRadius); // Draw a pulsing ellipse
  }
  